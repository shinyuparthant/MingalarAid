"""
This class is responsible for storeing all the information all the information about
the current state of the chess game. It will also keep a move log
also responsible for determining the valid moves

"""
from operator import truediv


class gameState:
    def __init__(self):
        #board is an 8 x 8 2D list each element of the list has 2 characters
        #b/w  is the color of the pieces
        # R,N,B,K,Q,p represents the type of pieces
        #  -- represents empty space
        self.board = [
            ["bR","bN","bB","bQ","bK","bB","bN","bR"],
            ["bp","bp","bp","bp","bp","bp","bp","bp"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["wp","wp","wp","wp","wp","wp","wp","wp"],
            ["wR","wN","wB","wQ","wK","wB","wN","wR"]
        ]
        self.whiteToMove = True
        self.moveLog = []
