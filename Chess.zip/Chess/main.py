"""
This is our main driver file.
It is responsible for handling user input and displaying the current game state object.

"""

import pygame as p
from pygame.examples.aliens import load_image

import Chess
from Chess import Engine

WIDTH = HEIGHT = 512 #400 is another option
DIMENSION = 8
SQ_SIZE =   HEIGHT  // DIMENSION
MAX_FPS = 15 #later for animation

IMAGES = {}

'''
Initialize a global dictionary of images. This will be called exactly once
in main
'''

def loadImages():
    pieces = ['wp','wR','wN','wB','wQ','wK','bp','bR','bN','bB','bQ','bK']
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(p.image.load("images/"+piece+".png"),(SQ_SIZE,SQ_SIZE))
    #Note : we can access an image by saying Images['wp']

'''
This will the main driver
'''

def main():
    p.init()
    screen = p.display.set_mode((WIDTH,HEIGHT))
    clock = p.time.Clock()
    screen.fill(p.Color("white"))
    gs = Engine.gameState()
    print(gs.board)
    loadImages() #only do this once, before the while loop
    running = True
    while running:
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
        clock.tick(MAX_FPS)
        drawGameState(screen, gs)
        p.display.flip()
'''
Draws the Squares on the board 
Responsible for all the graphics within a current game.
'''
def drawGameState(screen,gs):
    drawBoard(screen) #Draws the board
    #add piece highlighting or move suggestion
    drawPieces(screen,gs.board) # Draws the pieces
'''
Draws the Squares. Top Left is always light  square
'''
def drawBoard(screen):
    colors = [p.Color(239, 216, 182),p.Color(180, 135, 101)]
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            color = colors[((r + c) % 2)]
            p.draw.rect(screen, color,p.Rect(c*SQ_SIZE,r*SQ_SIZE,SQ_SIZE,SQ_SIZE))



'''
Draws the pieces
'''
def drawPieces(screen,board):
    for row in range(DIMENSION):
        for col in range(DIMENSION):
            piece = board[row][col]
            if piece != "--":
                screen.blit(IMAGES[piece], p.Rect(col*SQ_SIZE,row*SQ_SIZE,SQ_SIZE,SQ_SIZE))



if __name__ == '__main__':
    main()